﻿[
    { "lang": "ar", "name": "Arabic", "desc": "العربية" },
    { "lang": "fr", "name": "French", "desc": "Français" },
    { "lang": "it", "name": "Italian", "desc": "Italiano" },
]