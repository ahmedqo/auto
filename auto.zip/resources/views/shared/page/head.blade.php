<div slot="header" id="header-content">
    <div id="content">
        <img id="logo" src="{{ Core::company()->Image->Link }}" />
    </div>
    <div id="separater">
        <div></div>
        <div></div>
        <div></div>
    </div>
</div>
