 <div slot="header" id="header-content">
     <h1>
         {{ ucwords(Core::company()->name) }}
     </h1>
     <img src="{{ Core::company()->Image->Link }}" />
 </div>
